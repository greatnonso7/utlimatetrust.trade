<div class="deznav">
  <div class="deznav-scroll">
    <ul class="metismenu" id="menu">
      <li>
        <a class="ai-icon" href="index.php" aria-expanded="false">
          <i class="flaticon-381-networking"></i>
          <span class="nav-text">Dashboard</span>
        </a>
      </li>
      <li><a class="ai-icon" href="users.php" aria-expanded="false">
          <i class="flaticon-381-television"></i>
          <span class="nav-text">Members</span>
        </a>
      </li>
      <li><a class="ai-icon" href="investments.php" aria-expanded="false">
          <i class="flaticon-381-controls-3"></i>
          <span class="nav-text">Investments</span>
        </a>
      </li>
      <li><a class="ai-icon" href="deposits.php" aria-expanded="false">
          <i class="flaticon-381-internet"></i>
          <span class="nav-text">Deposits</span>
        </a>
      </li>
      <li><a class="ai-icon" href="withdrawals.php" aria-expanded="false">
          <i class="flaticon-381-heart"></i>
          <span class="nav-text">Withdrawals</span>
        </a>
      </li>
      <li><a href="transfers.php" class="ai-icon" aria-expanded="false">
          <i class="flaticon-381-settings-2"></i>
          <span class="nav-text">Transfers</span>
        </a>
      </li>
      <li><a class="ai-icon" href="referrals.php" aria-expanded="false">
          <i class="flaticon-381-notepad"></i>
          <span class="nav-text">Referrals</span>
        </a>
      </li>
      <!-- <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
          <i class="flaticon-381-network"></i>
          <span class="nav-text">Table</span>
        </a>
      </li> -->
      <li><a class="ai-icon" href="logout.php" aria-expanded="false">
          <i class="flaticon-381-layer-1"></i>
          <span class="nav-text">Logout</span>
        </a>
      </li>
    </ul>
  </div>
</div>