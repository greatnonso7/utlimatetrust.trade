<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ultimate_trade";

$connection = mysqli_connect($servername, $username, $password, $dbname);
